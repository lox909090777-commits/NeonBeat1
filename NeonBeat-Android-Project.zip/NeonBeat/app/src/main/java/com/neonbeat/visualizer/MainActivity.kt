package com.neonbeat.visualizer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val audioPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openNotificationAccess()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NeonBeatScreen(
            onEnable = { enableMonitoring() },
            onDisable = { stopService(Intent(this, MonitorService::class.java)) },
            onNotificationAccess = { openNotificationAccess() }
        ) }
    }

    private fun enableMonitoring() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            audioPermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        openNotificationAccess()
        getSharedPreferences("neonbeat", MODE_PRIVATE).edit().putBoolean("auto", true).apply()
        val intent = Intent(this, MonitorService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun openNotificationAccess() {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        if (!enabled.contains(packageName)) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
    }
}

@Composable
private fun NeonBeatScreen(onEnable: () -> Unit, onDisable: () -> Unit, onNotificationAccess: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("neonbeat", Activity.MODE_PRIVATE) }
    var sensitivity by remember { mutableFloatStateOf(prefs.getFloat("sensitivity", 1.6f)) }
    var bass by remember { mutableFloatStateOf(prefs.getFloat("bass", 1.5f)) }
    var style by remember { mutableStateOf(prefs.getString("style", "Spectrum") ?: "Spectrum") }
    var auto by remember { mutableStateOf(prefs.getBoolean("auto", false)) }
    val styles = listOf("Spectrum", "Кольцо", "Волна", "Импульс", "Частицы", "Зеркало", "Столбцы", "Неон")
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFB28CFF),
            secondary = Color(0xFF48DDEB),
            background = Color(0xFF090B13),
            surface = Color(0xFF151A29)
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF090B13)) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("NEONBEAT", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                Text("Музыка. Свет. Реакция.", color = Color(0xFF9EA8C5))
                VisualizerPreview(style)
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF151A29))) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Автоматический режим", color = Color.White, style = MaterialTheme.typography.titleLarge)
                        Text("Один раз включи доступы. После этого приложение будет следить за активными музыкальными сессиями.", color = Color(0xFFB9C1D8))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Автозапуск", color = Color.White, modifier = Modifier.weight(1f))
                            Switch(checked = auto, onCheckedChange = {
                                auto = it
                                prefs.edit().putBoolean("auto", it).apply()
                                if (it) onEnable() else onDisable()
                            })
                        }
                        Button(onClick = { auto = true; onEnable() }, modifier = Modifier.fillMaxWidth()) {
                            Text("Включить автоматический режим")
                        }
                        OutlinedButton(onClick = onNotificationAccess, modifier = Modifier.fillMaxWidth()) {
                            Text("Настроить доступ к уведомлениям")
                        }
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF151A29))) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Визуализация", color = Color.White, style = MaterialTheme.typography.titleLarge)
                        Text("Стиль: $style", color = Color(0xFFB9C1D8))
                        styles.chunked(2).forEach { pair ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                pair.forEach { item ->
                                    FilterChip(
                                        selected = style == item,
                                        onClick = { style = item; prefs.edit().putString("style", item).apply(); VisualizerWidget.updateAll(context) },
                                        label = { Text(item) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                if (pair.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                        Text("Чувствительность: ${(sensitivity * 100).toInt()}%", color = Color.White)
                        Slider(value = sensitivity, onValueChange = {
                            sensitivity = it
                            prefs.edit().putFloat("sensitivity", it).apply()
                        }, valueRange = 0.1f..3.0f)
                        Text("Усиление басов: ${(bass * 100).toInt()}%", color = Color.White)
                        Slider(value = bass, onValueChange = {
                            bass = it
                            prefs.edit().putFloat("bass", it).apply()
                        }, valueRange = 0.5f..3.0f)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF151A29))) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Размер виджета", color = Color.White, style = MaterialTheme.typography.titleLarge)
                        Text("Добавь NeonBeat на главный экран и растяни его пальцами до нужного размера. Поддерживается изменение ширины и высоты.", color = Color(0xFFB9C1D8))
                        Text("Экран блокировки: OxygenOS может не разрешать сторонние виджеты. Приложение оставляет уведомление о работе как запасной вариант.", color = Color(0xFF48DDEB))
                    }
                }
                Text("NeonBeat 1.0 • Для OnePlus / Android 8+", color = Color(0xFF68738F))
            }
        }
    }
}

@Composable
private fun VisualizerPreview(style: String) {
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(90)
            tick++
        }
    }
    Canvas(Modifier.fillMaxWidth().height(150.dp).background(
        Brush.linearGradient(listOf(Color(0xFF181A36), Color(0xFF0B2430))),
        RoundedCornerShape(22.dp)
    ).padding(14.dp)) {
        val bars = 42
        val gap = size.width * 0.012f
        val barWidth = (size.width - gap * (bars - 1)) / bars
        for (i in 0 until bars) {
            val wave = (kotlin.math.sin((i + tick * 0.16) * 0.48) * 0.5 + 0.5).toFloat()
            val h = size.height * (0.12f + wave * 0.78f)
            val x = i * (barWidth + gap)
            drawLine(
                brush = Brush.verticalGradient(listOf(Color(0xFF54E7F0), Color(0xFFB37CFF))),
                start = Offset(x + barWidth / 2, (size.height - h) / 2),
                end = Offset(x + barWidth / 2, (size.height + h) / 2),
                strokeWidth = barWidth,
                cap = StrokeCap.Round
            )
        }
    }
}
