package com.neonbeat.visualizer

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.widget.RemoteViews
import kotlin.math.max
import kotlin.math.sin

class VisualizerWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, VisualizerWidget::class.java))
            ids.forEach { updateOne(context, manager, it) }
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val prefs = context.getSharedPreferences("neonbeat", Context.MODE_PRIVATE)
            val level = prefs.getFloat("level", 0.12f)
            val bitmap = Bitmap.createBitmap(480, 180, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            paint.color = android.graphics.Color.rgb(13, 18, 34)
            canvas.drawColor(paint.color)
            val bars = 36
            val gap = 5f
            val w = (480f - gap * (bars - 1)) / bars
            for (i in 0 until bars) {
                val shape = (0.18f + (0.25f + 0.75f * level) * (0.5f + 0.5f * sin(i * 0.57 + System.currentTimeMillis() / 170.0))).toFloat()
                val h = max(8f, 150f * shape)
                paint.shader = android.graphics.LinearGradient(0f, 15f, 0f, 165f,
                    android.graphics.Color.rgb(70, 225, 239),
                    android.graphics.Color.rgb(174, 105, 255),
                    android.graphics.Shader.TileMode.CLAMP)
                canvas.drawRoundRect(RectF(i * (w + gap), (180f - h) / 2, i * (w + gap) + w, (180f + h) / 2), 5f, 5f, paint)
            }
            val views = RemoteViews(context.packageName, R.layout.widget_visualizer)
            views.setImageViewBitmap(R.id.widget_bars, bitmap)
            manager.updateAppWidget(id, views)
        }
    }
}
