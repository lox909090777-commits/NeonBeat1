package com.neonbeat.visualizer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.audiofx.Visualizer
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import kotlin.math.abs

class SessionListener : NotificationListenerService()

class MonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var visualizer: Visualizer? = null
    private var attachedSession = -1
    private val task = object : Runnable {
        override fun run() {
            try {
                val component = ComponentName(this@MonitorService, SessionListener::class.java)
                val manager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
                val playing = manager.getActiveSessions(component).firstOrNull {
                    it.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING
                }
                // MediaSession does not expose a public audio-session ID.
                // Session 0 asks Android's Visualizer for the output mix.
                if (playing != null && attachedSession != 0) attach(0)
                if (playing == null) {
                    visualizer?.enabled = false
                    getSharedPreferences("neonbeat", MODE_PRIVATE).edit().putFloat("level", 0f).apply()
                } else {
                    visualizer?.enabled = true
                }
                VisualizerWidget.updateAll(this@MonitorService)
            } catch (_: SecurityException) {
                // Notification-listener access may not have been granted yet.
            } catch (_: Exception) {
                // Keep the service alive if a media app exposes no usable session.
            }
            handler.postDelayed(this, 900)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = NotificationCompat.Builder(this, "neonbeat")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("NeonBeat активен")
            .setContentText("Автоматическое обнаружение музыки включено")
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(7, notification)
        }
        handler.post(task)
    }

    private fun attach(id: Int) {
        try {
            visualizer?.release()
            visualizer = Visualizer(id).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1]
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer, waveform: ByteArray, samplingRate: Int) {
                        val raw = waveform.sumOf { abs(it.toInt() - 128) }.toFloat() / (waveform.size * 128f)
                        saveLevel(raw)
                    }
                    override fun onFftDataCapture(v: Visualizer, fft: ByteArray, samplingRate: Int) {
                        if (fft.isNotEmpty()) {
                            val raw = fft.drop(2).take(fft.size / 2).sumOf { abs(it.toInt()).toDouble() }.toFloat() / (fft.size * 64f)
                            saveLevel(raw)
                        }
                    }
                }, Visualizer.getMaxCaptureRate() / 2, true, true)
                enabled = true
            }
            attachedSession = id
        } catch (_: Exception) {
            visualizer = null
            attachedSession = -1
        }
    }

    private fun saveLevel(raw: Float) {
        val prefs = getSharedPreferences("neonbeat", MODE_PRIVATE)
        val sensitivity = prefs.getFloat("sensitivity", 1.6f)
        val level = (raw * sensitivity).coerceIn(0f, 1f)
        prefs.edit().putFloat("level", level).apply()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel("neonbeat", "NeonBeat", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onDestroy() {
        handler.removeCallbacks(task)
        visualizer?.release()
        visualizer = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}

class BootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED &&
            context.getSharedPreferences("neonbeat", Context.MODE_PRIVATE).getBoolean("auto", false)) {
            try {
                androidx.core.content.ContextCompat.startForegroundService(context, Intent(context, MonitorService::class.java))
            } catch (_: Exception) { }
        }
    }
}
